<!-- JS da promptdan foydalandim -->
<!-- parseFloat dan ham foydalanganman -->

Data types(ma'lumot turlari) 2 turga bo'linadi:
1)Sodda(Primitive)
null
undefined
number
bigint
string
symbol

2)Murakkab(Complex)
object
.
typeof-----Biror bir ma'lumotni qaysi ma'lumot turidan ekanligini topish uchun ishlatiladi
.
Stringda yozishni 3 xil usuli bor:
1)let backTicks = `To'rayev Nurjahon`;
2)let doubleQuute = "To'rayev Nurjahon";
3)let singleQuote = 'To'rayev Nurjahon';
.
NaN - so'zining to'liq shakli -- Not A Number
.
undefined - e'lon qilingan o'zgaruvchining qiymat berilmagandagi holati
.
boolean da faqat 2 xil qiymat bo'ladi :
true(to'g'ri) va false(Xato)
PI -- Math.PI()
Modul -- Math.abs()
Ildiz osti -- Math.sqrt()
.
parseFloat -- string ni number ga aylantirishga yordam beradi
.
Math.trunc(x) - x ning butun qismini qaytaradi
.
Math.random() - 0 va 1 orasidagi random sonlar
