// JS da promptdan foydalandim
// parseFloat dan ham foydalanganman
/*
.
.
.
.
*/
////////////1-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let Y = -(B / 2) * (B ** 2 + A ** 2);
console.log(`Javob: ${Y}`);
*/
////////////2-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
let D = prompt("D ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
D = parseFloat(D);
let Y = ((A + B) / (C + D)) ** 2 + B ** 2;
console.log(`Javob: ${Y}`);
*/
////////////3-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
let D = prompt("D ning qiymatini kiriting");
A = parseFloat(A);
C = parseFloat(C);
D = parseFloat(D);
let Y = 2 * (A ** D + (4 * C ** 2) / 3);
console.log(`Javob: ${Y}`);
*/
////////////4-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
let D = prompt("D ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
D = parseFloat(D);
let Y = (1 / A ** 2) * (B / 10) ** 3 * (C + D) ** 2;
console.log(`Javob: ${Y}`);
*/
////////////5-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
let D = prompt("D ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
D = parseFloat(D);
let Y = ((A / B - 1) / (C / (D - 1))) ** 2;
console.log(`Javob: ${Y}`);
*/
////////////6-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
let D = prompt("D ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
D = parseFloat(D);
let Y = (A + B) / (C + D / (A + C));
console.log(`Javob: ${Y}`);
*/
////////////7-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
let Y = Math.sqrt((A + B + C) ** 2 - (A - B - C) ** 2);
console.log(Y);
*/
////////////8-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
let Y = (A ** 2 + B ** 2 + C ** 2) / (A * B * C);
console.log(`Javob: ${Y}`);
*/
////////////9-misol/////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
let D = prompt("D ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
D = parseFloat(D);
let Y = A * (D ** 3 / 3) + B * (C ** 2 / 2);
console.log(`Javob: ${Y}`);
*/
////////////10-misol////////
/*
let A = prompt("A ning qiymatini kiriting");
let B = prompt("B ning qiymatini kiriting");
let C = prompt("C ning qiymatini kiriting");
A = parseFloat(A);
B = parseFloat(B);
C = parseFloat(C);
let Y = Math.abs(A / B - B / C) + (A + C) ** 0.25;
console.log(`Javob: ${Y}`);
*/
